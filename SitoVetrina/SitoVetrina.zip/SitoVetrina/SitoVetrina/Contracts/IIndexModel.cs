﻿namespace SitoVetrina.Contracts
{
    public interface IIndexModel
    {
        public void VisualizzaProdotti(string url);
    }
}
